package com.example.kotlinproject.Model

data class MainCatList(val profileimage: Int, val name: String, val desc: String)