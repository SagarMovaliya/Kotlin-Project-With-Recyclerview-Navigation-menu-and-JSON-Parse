package com.example.kotlinproject.Model

data class SecondJsonList ( val personname: String, val emailid: String, val mobilenumber: String)
